import time

# Niveles de log simplificados
LOGINFO = 1

def log(message, level=LOGINFO):
    try:
        print(f"[xbmc] {message}")
    except Exception:
        pass

def getCondVisibility(expr):
    # Entorno de desarrollo: devolver False por defecto
    return False

def translatePath(path):
    # Compatibilidad mínima con llamadas antiguas que usan xbmc.translatePath
    try:
        # Manejo simple de special://
        if path.startswith('special://profile'):
            import os
            return os.path.expanduser('~/.kodi/userdata')
        if path.startswith('special://userdata'):
            import os
            return os.path.expanduser('~/.kodi/userdata')
        if path.startswith('special://temp'):
            import os
            return os.path.expanduser('~/.kodi/temp')
    except Exception:
        pass
    return path

def executeJSONRPC(cmd):
    # Devolver un JSON vacío razonable
    return '{"result":{}}'

def executebuiltin(cmd):
    # No-op en entorno de desarrollo
    return None

def sleep(ms):
    try:
        time.sleep(ms/1000.0)
    except Exception:
        pass

def getInfoLabel(label):
    return ''
