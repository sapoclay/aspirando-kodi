import os

def translatePath(path):
    # Mapeo básico para rutas special:// en entorno de desarrollo
    if path.startswith('special://profile'):
        return os.path.expanduser('~/.kodi/userdata')
    if path.startswith('special://userdata'):
        return os.path.expanduser('~/.kodi/userdata')
    if path.startswith('special://temp'):
        return os.path.expanduser('~/.kodi/temp')
    if path.startswith('special://home'):
        return os.path.expanduser('~')
    return path

def exists(path):
    try:
        return os.path.exists(path)
    except Exception:
        return False

class File:
    def __init__(self, path, mode='r'):
        self._path = path
        self._mode = mode
        self._fh = None
        try:
            # Crear el directorio padre si es modo escritura
            if 'w' in mode:
                parent = os.path.dirname(path)
                if parent and not os.path.exists(parent):
                    os.makedirs(parent, exist_ok=True)
            self._fh = open(path, mode, encoding='utf-8')
        except Exception:
            self._fh = None
    def write(self, data):
        if self._fh:
            try:
                self._fh.write(data)
            except Exception:
                pass
    def close(self):
        try:
            if self._fh:
                self._fh.close()
        except Exception:
            pass
