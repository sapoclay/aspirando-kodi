# Stub minimal para xbmcaddon
class Addon:
    def __init__(self, *args, **kwargs):
        self._info = {
            'id': 'script.aspirando-kodi',
            'name': 'Aspirando Kodi',
            'path': '.',
            'version': '0.0.0'
        }
        self._settings = {}

    def getAddonInfo(self, key):
        return self._info.get(key, '')

    def getSettingInt(self, key):
        try:
            return int(self._settings.get(key, 0))
        except Exception:
            return 0

    def getSetting(self, key):
        return str(self._settings.get(key, ''))

    def getSettingBool(self, key):
        return bool(self._settings.get(key, False))

    def getSettingNumber(self, key):
        try:
            return float(self._settings.get(key, 0))
        except Exception:
            return 0

    def setSetting(self, key, value):
        self._settings[key] = str(value)

    def setSettingBool(self, key, val: bool):
        self._settings[key] = bool(val)

    def setSettingNumber(self, key, val):
        try:
            self._settings[key] = float(val)
        except Exception:
            self._settings[key] = 0

    # Compatibilidad: getSettingBool/getSettingNumber/setSettingBool/setSettingNumber
    # ya están implementadas arriba. Añadimos alias si alguna llamada usa nombres distintos.
    def getSettingBool(self, key, fallback=False):
        return bool(self._settings.get(key, fallback))

    def getSettingNumber(self, key, fallback=0):
        try:
            return float(self._settings.get(key, fallback))
        except Exception:
            return float(fallback)
