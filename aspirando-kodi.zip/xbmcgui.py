# Stub minimal para xbmcgui usado en análisis estático
INPUT_ALPHANUM = 0

class Dialog:
    def ok(self, title, message):
        # Simular diálogo OK
        return None
    def yesno(self, title, message, yeslabel='Yes', nolabel='No'):
        # Por defecto, cancelar (False). Algunas llamadas esperan True; los tests interactivos deben ajustar.
        return False
    def select(self, title, items, useDetails=False):
        return -1
    def browse(self, type_, heading, shares='files', mask='', useThumbs=False, treatAsFolder=False, default=None):
        # Devuelve la ruta por defecto en stubs o cadena vacía
        try:
            return default or ''
        except Exception:
            return ''
    def input(self, heading, *args, **kwargs):
        # Acepta `type` o `type_` por compatibilidad y devuelve el valor por defecto
        default = kwargs.get('default', '')
        # permitir también primer arg posicional como default
        if args:
            # si se pasó un default como segundo parámetro posicional
            try:
                default = args[0]
            except Exception:
                pass
        try:
            return default
        except Exception:
            return ''
    def numeric(self, type_, heading, default=''):
        return default
    def textviewer(self, heading, text):
        return None
    def notification(self, title, message, time=3000):
        return None

class DialogProgress:
    def __init__(self):
        self._percent = 0
    def create(self, heading, message=''):
        return None
    def update(self, percent, message=''):
        self._percent = percent
        return None
    def close(self):
        return None

class Control:
    pass

class Window:
    pass
